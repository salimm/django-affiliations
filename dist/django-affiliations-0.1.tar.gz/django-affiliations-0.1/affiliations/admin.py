from django.contrib import admin
from affiliations.models import Affiliation
# Register your models here.

admin.site.register(Affiliation)